# -*- coding: utf-8 -*-
import xbmcaddon, xbmcplugin, xbmcgui, sys, xbmc, os, re, time, threading, io
from base64 import b64encode, b64decode 
import simplejson as json
from utils import *
try:
	from urlresolver import resolve
	from urlresolver import load_external_plugins
	from urlresolver.resolver import ResolverError
	from urlresolver.plugins.lib import helpers
except:
	from resolveurl import resolve
	from resolveurl import load_external_plugins
	from resolveurl.resolver import ResolverError
	from resolveurl.lib import helpers
	
BASEURL = 'https://www2.vjackson.info/ccapi/'
MAX_SEARCH_HISTORY_ITEMS = 20
DEBUG_HOSTERS = DEBUG
prevMirror = None
line1 = ""
line2 = ""
line3 = ""


def action_home(params):
	xbmc.executebuiltin('ActivateWindow(Home)')
	xbmcplugin.endOfDirectory(getPluginhandle())

def action_index(params):
	xbmcplugin.setContent(getPluginhandle(), 'files')
	addDir2("Live", "PVR", "channels")
	addDir2('Filme', 'movies', 'movielists')
	addDir2('Serien', 'series', 'serieslists')
	addDir2('Suche', 'search', 'search', id='all.popular')
	#import dldb2
	#if int(dldb2.Props.get("Entries") or 0)  > 0 :
		#addDir2("Downloads", "downloads", "download/list")
	addDir2('Einstellungen', 'settings', 'settings')
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

def movielists(params):
	xbmcplugin.setContent(getPluginhandle(), 'movies')
	addDir2('Beliebte Filme', 'movies', 'showlist', id='movie.popular')
	#addDir2('Beliebte Filme (Deutschland)', 'movies', 'showlist', id='movie.popularDE')
	addDir2('Angesagte Filme', 'movies', 'showlist', id='movie.trending')
	#addDir2('Angesagte Filme (Deutschland)', 'movies', 'showlist', id='movie.trendingDE')
	addDir2('Suche', 'search', 'search', id='movie.popular')
	addDir2('Einstellungen', 'settings', 'settings')
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

def serieslists(params):
	xbmcplugin.setContent(getPluginhandle(), 'tvshows')
	addDir2('Beliebte Serien', 'series', 'showlist', id='series.popular')
	addDir2('Angesagte Serien', 'series', 'showlist', id='series.trending')
	addDir2('Suche', 'search', 'search', id='series.popular')
	addDir2('Einstellungen', 'settings', 'settings')
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

STREAM_SELECT_OPTIONS = ('hosters2', 'auto', 'grouped')
LANGUAGE_NAMES = {'de': {'de': 'Deutsch', 'en': 'Englisch'}, 'en': {'de': 'German', 'en': 'English'}} 

def getStreamSelect():
	if DEBUG_HOSTERS:
		return 'hosters2'
	return STREAM_SELECT_OPTIONS[int(addon.getSetting('stream_select') or 0)]

def getAutoTryNextStream():
	if DEBUG_HOSTERS:
		return False
	return addon.getSetting('auto_try_next_stream') != 'false'

def prepareListItem(params, e, isPlayable=False, callback=None):
	infos = {}
	properties = {}

	def getMeta(*paths, **kwargs):
		for path in paths:
			f = e
			for p in path:
				try:
					f = f[p]
				except (KeyError, TypeError):
					f = None
					break
			if f:
				return f
		return kwargs.get('default', None)

	def setInfo(key, value):
		if value:
			if type(value) is list:
				infos[key] = (', ').join(value)
			else:
				infos[key] = value

	def setProperty(key, value):
		if value:
			properties[key] = value

	def setInfoPeople(key, value):
		if value:
			setInfo(key, value)
	title = e['name']
	attrs = []
	if attrs:
		title += ' (' + (', ').join(attrs) + ')'
	if 'channelName' in e:
		title = '[B]' + e['channelName'] + '[/B]: ' + title
	setInfo('title', title)
	setInfo('originaltitle', e['originalName'])
	setInfo('year', getMeta(('year', )))
	art = {'thumb': getMeta(('poster', ), default='DefaultVideo.png'), 'poster': getMeta(('poster', ), default='DefaultVideo.png'), 'banner': getMeta(('backdrop', ))}

	def updateInfos(data):
		setInfo('plot', data.get('description'))
		setInfo('code', data.get('id'))
		setInfo('premiered', data.get('releaseDate'))

	updateInfos(e)
	if not isMovie(e) and 'season' in params and 'current_episode' in e:
		ep = e['current_episode']
		season = params['season']
		episode = ep['episode']
		if season == 0:
			setInfo('TVShowTitle', 'Extras, Episode %s' % episode)
		else:
			setInfo('TVShowTitle', 'Season %s Episode %s' % (season, episode))
		setInfo('season', season)
		setInfo('episode', episode)
		episode_title = ep.get('name', None)
		if episode_title and not episode_title.startswith('Episode '):
			setInfo('TVShowTitle', episode_title)
		updateInfos(ep)
	genres = set()
	for g in getMeta(('genres', )) or tuple():
		genres.add(g)

	genres = (', ').join(sorted(genres))
	setInfo('genre', genres)
	countries = set()
	for g in getMeta(('countries', )) or tuple():
		countries.add(g)
	countries = (', ').join(sorted(countries))
	setInfo('country', countries)
	setInfoPeople('cast', getMeta(('cast', )))
	setInfo('director', getMeta(('director', )))
	setInfo('writer', getMeta(('writer', )))
	setProperty('selectaction', 'info')
	if isPlayable:
		setProperty('IsPlayable', 'true')
	#return (infos, properties, art, contextMenuItems)
	return (infos, properties, art)

def isMovie(e):
	a = e['id'].startswith('movie')
	if a:
		log(('!!!!!!!!!!!', e))
	return a

def createListItem(params, e, isPlayable=False, o=None, **kwargs):
	#infos, properties, art, contextMenuItems = prepareListItem(params, e, isPlayable=isPlayable, **kwargs)
	infos, properties, art = prepareListItem(params, e, isPlayable, **kwargs)
	if o is None:
		o = xbmcgui.ListItem()
	o.setInfo('Video', infos)
	o.setLabel(infos['title'])
	#o.addContextMenuItems(contextMenuItems, False)
	for key, value in list(properties.items()):
		if PY2:
			if not isinstance(value, basestring):
				value = str(value)
		o.setProperty(key, value)
		
	if art:
		o.setArt(art)
		if art['thumb']:
			o.setArt({"thumb":art["thumb"]})
	return o

def showlist(params):
	data = callApi2('list', {'id': params['id']})
	if isMovie(data['data'][0]):
		content = 'movies'
	else:
		content = 'tvshows'
	xbmcplugin.setContent(getPluginhandle(), content)
	items = []
	for i, e in enumerate(data['data']):
		if isMovie(e):
			isPlayable = True
			isFolder = False
			action = 'show'
		else:
			isPlayable = False
			isFolder = True
			action = 'getseasons'
		urlParams = {'action': action, 'id': str(e['id'])}
		o = createListItem(urlParams, e, isPlayable=isPlayable)
		items.append((i, urlParams, o, isFolder))

	for _, urlParams, o, isFolder in sorted(items):
		xbmcplugin.addDirectoryItem(getPluginhandle(), getPluginUrl(urlParams), o, isFolder)

	if data['next']:
		addDir('>>> Weiter', getPluginUrl({'action': 'showlist', 'id': data['next']}))
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

class search(object):
	db = None

	def __init__(self, params):
		self.params = params
		history = self.getHistory()
		if 'query' in params:
			params['query'] = py2dec(params['query'])
			if params.get('exact') == 'true' and not params['query'].startswith('"'):
				params['query'] = '"' + params['query'] + '"'
			if params['query'] == '-':
				oKeyboard = xbmc.Keyboard(history[0] if history else '')
				oKeyboard.doModal()
				if not oKeyboard.isConfirmed():
					self.index(history)
					return
				params['query'] = oKeyboard.getText().strip()
				if not params['query']:
					self.index(history)
					return
				params['query'] = py2dec(params['query'])
			elif 'delete' in params:
				c = self.getDatabase().cursor()
				try:
					try:
						c.execute('DELETE FROM search_history WHERE query=?', [params['query']])
						self.db.commit()
					except Exception:
						import traceback
						log(traceback.format_exc())
						
				finally:
					c.close()
					
				self.index(self.getHistory())
				return
			if params.get('history', 'true') == 'true':
				c = self.getDatabase().cursor()
				try:
					try:
						c.execute('REPLACE INTO search_history (query, t) VALUES (?, ?)', [params['query'], int(time.time())])
						self.db.commit()
					except Exception:
						import traceback
						log(traceback.format_exc())
				finally:
					c.close()
			params['query'] = py2enc(params['query'])
			params['id'] = '%s.search=%s' % (params['id'], params['query'].replace('.', '%2E'))
			showlist(params)
		else:
			self.index(history)

	def getDatabase(self):
		if not self.db:
			self.db = Database(filename='vjackson.db')
			c = self.db.cursor()
			try:
				try:
					c.execute('CREATE TABLE IF NOT EXISTS search_history (query TEXT PRIMARY KEY, t INTEGER)')
					self.db.commit()
				except Exception:
					import traceback
					log(traceback.format_exc())

			finally:
				c.close()

		return self.db

	def getHistory(self):
		c = self.getDatabase().cursor()
		result = []
		try:
			try:
				c.execute('SELECT query FROM search_history ORDER BY t DESC')
				for query, in c:
					result.append(query)
				for query in result[MAX_SEARCH_HISTORY_ITEMS - 1:]:
					c.execute('DELETE FROM search_history WHERE query=?', [query])
				self.db.commit()
			except Exception:
				import traceback
				log(traceback.format_exc())
		finally:
			c.close()
		return result

	def index(self, history):
		addDir2('Neue Suche', 'search', 'search', id=self.params.get('id', 'all.popular'), query='-')
		for query in history:
			url = getPluginUrl({'action': 'search', 'id': self.params['id'], 'query': py2enc(query)})
			liz = xbmcgui.ListItem(query)
			liz.setArt({"icon":'DefaultFolder.png', "thumb":getIcon('query')})
			liz.setInfo(type='Video', infoLabels={'Title': query})
			ctx = [('Löschen', 'ActivateWindow(Videos,' + url + '&delete=1)')]
			liz.addContextMenuItems(ctx, False)
			xbmcplugin.addDirectoryItem(getPluginhandle(), url, liz, True)
		addDir2('Einstellungen', 'settings', 'settings')
		xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

def getseasons(params):
	id = params['id']
	#getParamsLanguage(params)
	data = callApi2('info', params)
	seasons = list(data['seasons'].keys())
	if len(seasons) == 1:
		params['season'] = seasons[0]
		getepisodes(params, data)
		return
	xbmcplugin.setContent(getPluginhandle(), 'seasons')
	params['action'] = 'getepisodes'
	urlParams = {'action': 'getepisodes', 'id': str(id)}
	for i in seasons:
		params['season'] = str(i)
		urlParams['season'] = str(i)
		o = createListItem(params, data)
		if i == 0:
			o.setLabel('Extras')
		else:
			o.setLabel('Season ' + str(i))
		xbmcplugin.addDirectoryItem(getPluginhandle(), getPluginUrl(params), o, True)
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

def getepisodes(params, data=None):
	id = params['id']
	season = str(params['season'])
	#if 'language' not in params:
		#getParamsLanguage(params)
	xbmcplugin.setContent(getPluginhandle(), 'episodes')
	if data is None:
		data = callApi2('info', params)
	season = str(params.pop('season'))
	urlParams = {'action': 'show', 'id': str(id)}
	params = {'action': 'show', 'id': str(id)}
	#params = {'action': 'show', 'season': season}
	for i in data['seasons'][season]:
		params['id'] = '%s.%s.%s' % (data['id'], season, i['episode'])
		data['current_episode'] = i
		o = createListItem(params, data, isPlayable=True)
		o.setLabel('Season ' + season + ' Episode ' + str(i['episode']))
		xbmcplugin.addDirectoryItem(getPluginhandle(), getPluginUrl(params), o, False)
	xbmcplugin.endOfDirectory(getPluginhandle(), succeeded=True, cacheToDisc=True)

class show(object):

	def __init__(self, params):
		self.params = params
		self.db = None
		self.mirrorsTried = 0
		self.run()
		return

	def getDatabase(self):
		if not self.db:
			self.db = Database(filename='vjackson.db')
			c = self.db.cursor()
			try:
				try:
					c.execute('CREATE TABLE IF NOT EXISTS hoster_weights (hoster TEXT, t INTEGER)')
					self.db.commit()
				except Exception:
					import traceback
					log(traceback.format_exc())
			finally:
				c.close()
		return self.db

	def getHosterWeights(self):
		weights = {}
		c = self.getDatabase().cursor()
		try:
			try:
				c.execute('DELETE FROM hoster_weights WHERE t<?', [int(time.time()) - 604800])
				c.execute('SELECT hoster, COUNT(*) FROM hoster_weights')
				self.getDatabase().commit()
				for hoster, weight in c:
					if hoster:
						weights[hoster] = weight
			except Exception:
				import traceback
				log(traceback.format_exc())
		finally:
			c.close()
		return weights

	def getStreamSelect(self):
		return getStreamSelect()

	def setSuccessfulConnection(self, hoster):
		c = self.getDatabase().cursor()
		try:
			try:
				c.execute('INSERT INTO hoster_weights (hoster, t) VALUES (?, ?)', [hoster, int(time.time())])
				self.getDatabase().commit()
			except Exception:
				import traceback
				log(traceback.format_exc())
		finally:
			c.close()

	def init(self):
		self.player = xbmc.Player()
		self.player.stop()
		if self.params.get('singleUrl', None):
			self.data = {'name': 'singleUrl', 'originalName': 'singleUrl'}
			self.mirrors = [{'type': 'url', 'url': self.params['singleUrl'], 'language': 'de'}]
		else:
			self.data = callApi2('info', self.params)
			self.mirrors = callApi2('links', self.params)
			if not self.mirrors:
				raise ValueError('keine mirrors gefunden')
			return False
		return

	def run(self):
		if self.init():
			return
		else:
			#weights = self.getHosterWeights()
			#SUPERWEIGHTS = {'clipboard.cc': 5, 'kinoger.com': 4, 'openload.co': 3, 'streamango.com': 2, 'streamcloud.eu': 1}
			self.groups = []
			groupsByLanguage = {}
			locale = getLocale(self.params)
			for i, mirror in enumerate(self.mirrors):
				if 'hoster' not in mirror:
					mirror['hoster'] = urlparse(mirror['url']).netloc
				mirror['caption'] = mirror['hoster']
				#mirror['weight'] = SUPERWEIGHTS.get(mirror['hoster'], 0) * 10000000 + weights.get(mirror['hoster'], 0) * 1
				#log('WEIGHT = %s /// %s %s /// %s' % (mirror['weight'],SUPERWEIGHTS.get(mirror['hoster'], 0),weights.get(mirror['hoster'], 0),mirror['hoster']))
				mirror['language'] = mirror.get('language', mirror.get('languages', ['??'])[0])
				if mirror['language'] not in groupsByLanguage:
					attrs = []
					attrs.append(LANGUAGE_NAMES[locale].get(mirror['language'], mirror['language']))
					group = {'caption': (', ').join(attrs), 'mirrors': []}
					group['priority'] = i
					self.groups.append(group)
					groupsByLanguage[mirror['language']] = group
				groupsByLanguage[mirror['language']]['mirrors'].append(mirror)
			self.mirrors = []
			#self.groups = list(sorted(self.groups, key=lambda x: x['priority']))
			for group in self.groups:
				n = len(group['mirrors'])
				group['caption'] += ' (%s Mirrors)' % n
				#group['mirrors'] = list(sorted(group['mirrors'], key=lambda m: -m['weight']))
				self.mirrors.extend(group['mirrors'])
			#getHosters(self.params)
			self.streamSelect = self.getStreamSelect()
			if self.streamSelect == 'grouped':
				heading = 'Sprache wählen'
				captions = [ mirror['caption'] for mirror in self.groups ]
			elif self.streamSelect == 'hosters':
				heading = 'Hoster wählen'
				captions = [ mirror['caption'] for mirror in self.mirrors ]
			elif self.streamSelect == 'hosters2':
				heading = 'Hoster wählen'
				captions = [ mirror['caption'] for mirror in self.mirrors ]
			#elif self.streamSelect == 'hosters2':
				#heading = 'Hoster wählen'
				#captions = []
				#for i, mirror in enumerate(self.mirrors):
					#mirror['caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', urlparse(mirror['url']).netloc))
					#mirror['short_caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', mirror['hoster']))
					#captions.append(mirror['caption'])
			elif self.streamSelect != 'auto':
				raise RuntimeError('Invalid value for streamSelect: %s' % self.streamSelect)
			if self.streamSelect != 'auto':
				index = xbmcgui.Dialog().select(heading, captions)
				if index < 0:
					return
			else:
				index = 0
			if self.streamSelect == 'grouped':
				self.mirrors = self.groups[index]['mirrors']
			elif self.streamSelect == 'hosters':
				mirror = self.mirrors[index]
				group = groupsByLanguage[mirror['language']]
				self.mirrors = group['mirrors'][group['mirrors'].index(mirror):]
			elif self.streamSelect == 'hosters2':
				self.mirrors = self.mirrors[index:]
			if self.streamSelect in ('hosters', 'hosters2') and not getAutoTryNextStream():
				self.mirrors = [self.mirrors[0]]
			load_external_plugins()
			self.initProgress()
			try:
				try:
					self.findMirror()
				except Exception as e:
					if str(e) == 'CANCELED':
						return
					if str(e) == 'FAILED':
						self.showFailedNotification()
						return
					raise
			finally:
				if self.progress is not None:
					self.progress.close()
					self.progress = None
			return

	def showFailedNotification(self):
		xbmc.executebuiltin('Notification(%s,%s,%s,%s)' % ('VAVOO.TO', 'Beim aufrufen des Streams ist ein Fehler aufgetreten', 5000, addon.getAddonInfo('icon')))

	def initProgress(self):
		self.progress = xbmcgui.DialogProgress()
		self.progress.create('VAVOO.TO', 'Der Stream wird gestartet...')

	def checkCanceled(self):
		if self.progress.iscanceled():
			raise ValueError('CANCELED')

	def setMirrorProgress(self, step):
		STEPS_PER_MIRROR = 4
		current = step
		total = STEPS_PER_MIRROR
		if self.progress is None:
			self.initProgress()
		if PY2:
			self.progress.update(int(current * (100.0 / total)), line1, line2, line3)
		else:
			self.progress.update(int(current * (100.0 / total)), line1+"\n"+line2+"\n"+line3)
		self.checkCanceled()

	def findMirror(self):
		global prevMirror
		global line1
		global line2
		for self.mirrorIndex, mirror in enumerate(self.mirrors):
			if self.mirrorIndex == 0:
				line1 = 'Die Wiedergabe wird gestartet.'
				line2 = mirror.get('short_caption', mirror['caption'])
			else:
				line1 = '%s fehlgeschlagen.' % prevMirror.get('short_caption', mirror['caption'])
				line2 = 'Versuche %s...' % mirror.get('short_caption', mirror['caption'])
			self.setMirrorProgress(0)
			prevMirror = mirror
			self.checkCanceled()
			url = mirror.get('url', None)
			if url is None:
				continue
			url = url.replace('https://nullrefer.com/?', '')
			resolvedUrl = self.resolveUrl(mirror, url)
			if not resolvedUrl:
				continue
			self.setMirrorProgress(1)
			try:
				if self.tryMirror(mirror, url, resolvedUrl):
					return
			except:
				pass
		raise ValueError('FAILED')
		return

	def resolveUrl(self, mirror, url):
		log('Resolving URL: %s' % url)
		cacheKey = url
		originalUrl = url
		cachedUrl = None
		if cachedUrl:
			log('Got resolved URL from cache: %s' % cachedUrl)
			return cachedUrl
		else:
			url = self.resolveUrl1(mirror, originalUrl)
			log('Resolve 1: %s' % url)
			if not url:
				url = self.resolveUrl2(mirror, originalUrl)
				log('Resolve 2: %s' % url)
			if url:
				#if xbmc.getCondVisibility('system.platform.android') and '.m3u8' in url:
					#log('video not for android')
					#return
				#cache['short'].set(cacheKey, url)
				return url
			if url is False:
				log('Reporting not working URL: %s' % url)
			return

	def resolveUrl1(self, mirror, url):
		try:
			return resolve(url)
		except Exception:
			import traceback
			log(traceback.format_exc())
			return
		return

	def resolveUrl2(self, mirror, url):
		try:
			res = callApi2('open', {'link': url})
			if not res:
				raise ValueError('no link')
			return res[0]['url'] + helpers.append_headers(res[0].get('headers', {}))
		except Exception:
			import traceback
			log(traceback.format_exc())
			return
		return

	def tryMirror(self, mirror, url, resolvedUrl):
		log('Trying resolved URL: %s' % resolvedUrl)
		try:
			resolvedUrl = fix_stream_url(resolvedUrl)
			o = createListItem(self.params, self.data, isPlayable=True)
			o.setPath(resolvedUrl)
			self.player.play(resolvedUrl, o)
			self.mirrorsTried += 1
			step = 1
			STEP_TIMEOUT = 45
			abortReason = ''
			t = time.time()
			try:
				sleep = 10
				while not abortReason:
					if xbmc.Monitor().abortRequested() or self.progress and self.progress.iscanceled():
						abortReason = 'canceled'
					elif step == 1:
						if self.player.isPlaying():
							self.setMirrorProgress(2)
							step = 2
						elif time.time() - t > STEP_TIMEOUT:
							abortReason = 'timeout'
					elif step == 2:
						if self.player.getTime() > 0.0:
							global line3
							line3='Viel Spaß mit VAVOO!'
							self.setMirrorProgress(3)
							#self.player.stop()
							sleep = 100
							step = 3
						elif not self.player.isPlaying():
							abortReason = 'died'
					elif step == 3:
						if self.player.isPlaying():
							xbmcplugin.setResolvedUrl(getPluginhandle(), True, o)
							t = time.time()
							step = 4
					elif step == 4:
						if self.player.isPlaying():
							self.setMirrorProgress(4)
							step = 5
						elif time.time() - t > STEP_TIMEOUT:
							abortReason = 'timeout'
					elif step == 5:
						if not self.player.isPlaying():
							abortReason = 'stopped'
						elif self.player.getTime() > 0.1:
							resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
							if resolution:
								#self.setSuccessfulConnection(mirror['hoster'])
								if self.progress is not None:
									self.progress.close()
									self.progress = None
								sleep = 1000
								step = 6
					elif step == 6:
						if not self.player.isPlaying():
							abortReason = 'stopped'
					else:
						raise RuntimeError('Unknow step: %r' % step)
					if not abortReason:
						xbmc.sleep(sleep)
				log('Player stopped: reason=%s' % (abortReason))
			finally:
				self.player.stop()
			if abortReason in ('canceled', 'stopped'):
				return True
			if step >= 4:
				raise RuntimeError('Stream died! reason=%s' % (abortReason))
			return False
		except Exception:
			import traceback
			log(traceback.format_exc())
			return False
		return

def addDir(name, url, iconimage="DefaultFolder.png", isFolder=True, isPlayable=False):
	liz = xbmcgui.ListItem(name)
	liz.setArt({"icon":iconimage, "thumb":iconimage})
	liz.setInfo(type="Video", infoLabels={"Title": name})
	if isPlayable:
		liz.setProperty("IsPlayable", "true")
	xbmcplugin.addDirectoryItem(getPluginhandle(), url, liz, isFolder)

def addDir2(name_, icon_, action, **params):
	params['action'] = action
	addDir(name_, getPluginUrl(params), getIcon(icon_))

def getIcon(name):
	return py2dec(translatePath('special://home/addons/' + addonID + '/resources/' + name + '.png'))

def callApi(action, params, method='GET', headers=None, **kwargs):
	log('callApi req: %s' % json.dumps(params))
	if not headers:
		headers = dict()
	headers['auth-token'] = getAuthSignature()
	resp = getSession().request(method, (BASEURL + action), params=params, headers=headers, **kwargs)
	resp.raise_for_status()
	#data = json.loads(resp.content.decode('utf-8'))
	data = json.loads(resp.content)
	log('callApi res: %s' % json.dumps(data))
	return data

def callApi2(action, params, **kwargs):
	res = callApi(action, params)
	#while True:
	if type(res) is not dict or 'id' not in res or 'data' not in res:
		return res
	import requests
	session = requests.session()
	data = res['data']
	return data
	"""
	if type(data) is dict and data.get('type') == 'fetch':
		params = data['params']
		body = params.get('body')
		headers = params.get('headers')
		resp = session.request(params.get("method", "GET").upper(), data["url"], headers={k:v[0] if type(v) in (list, tuple) else v for k, v in list(headers.items())} if headers else None, data=b64decode(body) if body else None, allow_redirects=params.get("redirect", "follow") == "follow")
		headers = dict(resp.headers)
		resData = {"status": resp.status_code, "url": resp.url, "headers": headers, "data": b64encode(resp.content).decode("utf-8").replace("\n", "") if data["body"] else None}
		res = callApi('res', {'id': res['id']}, method='POST', json=resData)
	elif type(data) is dict and data.get('error'):
		raise ValueError(data['error'])
	else:
		return data
	return
	"""
	
def main():
	params = dict(parse_qsl(sys.argv[2].replace('?','')))
	action = params.get('action', '')
	tv = params.get('name', '')
	if not params:
		action_index(params)
	elif tv and not action:
		import vjlive
		vjlive.livePlay(params['name'])
	elif action == 'choose':
		import vjlive
		vjlive.choose()
	elif action == 'channels':
		import vjlive
		vjlive.channels()
	elif action == 'settings':
		addon.openSettings(sys.argv[1])
	else:
		globals()[params['action']](params)
		
if __name__ == '__main__':
	main()